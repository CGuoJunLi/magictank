import 'package:flutter/cupertino.dart';

class ProgressSmart {
  // int _currentpage = 0;
  void progressbtsmartdata(List<int> data) {
    switch (data[0]) {
      case 0:
        debugPrint("0");
        //  _currentpage = 0;
        break;
      case 1:
        break;
    }
  }
}

ProgressSmart progressSmart = ProgressSmart();
