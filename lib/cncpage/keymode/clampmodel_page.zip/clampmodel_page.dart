//夹取模型

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:magictank/appdata.dart';
import 'package:magictank/cncpage/bluecmd/cmd.dart';
import 'package:magictank/cncpage/bluecmd/receivecmd.dart';
import 'package:magictank/cncpage/bluecmd/sendcmd.dart';
import 'package:magictank/dialogshow/dialogpage.dart';
import 'package:magictank/generated/l10n.dart';

import '../createkeydata.dart';

class ClampModelPage extends StatelessWidget {
  final Map arguments;
  const ClampModelPage(
    this.arguments, {
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0XFF6E66AA),
        leading: IconButton(
          icon: const Icon(Icons.chevron_left),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: Image.asset(
          "image/tank.png",
          scale: 2.0,
        ),
      ),
      body: ClampModel(
        arguments,
      ),
    );
  }
}

class ClampModel extends StatefulWidget {
  final Map arguments;
  const ClampModel(
    this.arguments, {
    Key? key,
  }) : super(key: key);

  @override
  State<ClampModel> createState() => _ClampModelState();
}

class _ClampModelState extends State<ClampModel> {
  int side = 0;
  int no = 0;
  int type = 0;
  List<String> imagePath = [];
  List<String> tipMessage = [];
  String gifPath = "";
  @override
  void initState() {
    if (widget.arguments["type"] == 2) {
      debugPrint("完成");
      side = 5;
    } else {
      switch (widget.arguments["message"]) {
        case 13:
          side = 1;
          break;
        case 14:
          side = 2;
          break;
        case 15:
          side = 3;
          break;
        case 16:
          side = 4;
          break;
      }
    }
    no = widget.arguments["no"];
    super.initState();
  }

  List<Widget> clampkey() {
    List<Widget> temp = [];
    imagePath = [];
    tipMessage = [];
    switch (side) {
      case 1:
        if (cnCversion.fixtureType == 21) {
          //新夹具

          tipMessage.add(S.of(context).model_fixture1_11);
          tipMessage.add(S.of(context).model_fixture1_12);
          tipMessage.add(S.of(context).model_fixture1_13);

          if (baseKey.keyClass == 10) {
            //平铣类型
            gifPath = appData.keyimagepath + "/fixture/model/1_5_1.gif";
            for (var i = 1; i < 4; i++) {
              imagePath.add("1_5_1_$i.png");
            }
          } else {
            //立铣类型 9
            gifPath = appData.keyimagepath + "/fixture/model/1_0_1.gif";
            for (var i = 1; i < 4; i++) {
              imagePath.add("1_0_1_$i.png");
            }
          }
        } else {
          //旧家具
          tipMessage.add(S.of(context).model_fixture0_11);
          tipMessage.add(S.of(context).model_fixture0_12);
          tipMessage.add(S.of(context).model_fixture0_13);

          if (baseKey.keyClass == 10) {
            //平铣类型
            gifPath = appData.keyimagepath + "/fixture/model/0_5_1.gif";
            for (var i = 1; i < 4; i++) {
              imagePath.add("0_5_1_$i.png");
            }
          } else {
            //立铣类型 9
            gifPath = appData.keyimagepath + "/fixture/model/0_0_1.gif";
            for (var i = 1; i < 4; i++) {
              imagePath.add("0_0_1_$i.png");
            }
          }
        }

        break;
      case 2:
        if (cnCversion.fixtureType == 21) {
          //新夹具
          tipMessage.add(S.of(context).model_fixture1_21);
          tipMessage.add(S.of(context).model_fixture1_22);
          tipMessage.add(S.of(context).model_fixture1_23);

          if (baseKey.keyClass == 10) {
            //平铣类型
            gifPath = appData.keyimagepath + "/fixture/model/1_5_1.gif";
            for (var i = 1; i < 4; i++) {
              imagePath.add("1_5_2_$i.png");
            }
          } else {
            //立铣类型 9
            gifPath = appData.keyimagepath + "/fixture/model/1_0_1.gif";
            for (var i = 1; i < 4; i++) {
              imagePath.add("1_0_2_$i.png");
            }
          }
        } else {
          //旧家具
          tipMessage.add(S.of(context).model_fixture0_21);
          tipMessage.add(S.of(context).model_fixture0_22);
          tipMessage.add(S.of(context).model_fixture0_23);

          if (baseKey.keyClass == 10) {
            //平铣类型
            gifPath = appData.keyimagepath + "/fixture/model/0_5_1.gif";
            for (var i = 1; i < 4; i++) {
              imagePath.add("0_5_2_$i.png");
            }
          } else {
            //立铣类型 9
            gifPath = appData.keyimagepath + "/fixture/model/0_0_1.gif";
            for (var i = 1; i < 4; i++) {
              imagePath.add("0_0_2_$i.png");
            }
          }
        }
        break;
      case 3:
        if (cnCversion.fixtureType == 21) {
          //新夹具
          if (baseKey.locat == 1) {
            tipMessage.add(S.of(context).model_fixture1_31);
            tipMessage.add(S.of(context).model_fixture1_32);
            tipMessage.add(S.of(context).model_fixture1_33);

            if (baseKey.keyClass == 10) {
              //平铣类型
              gifPath = appData.keyimagepath + "/fixture/model/1_0_3.gif";
              for (var i = 1; i < 4; i++) {
                imagePath.add("1_5_3_$i.png");
              }
            } else {
              //立铣类型 9
              gifPath = appData.keyimagepath + "/fixture/model/1_0_3.gif";
              for (var i = 1; i < 4; i++) {
                imagePath.add("1_0_3_$i.png");
              }
            }
          } else {
            tipMessage.add(S.of(context).model_fixture1_51);
            tipMessage.add(S.of(context).model_fixture1_52);
            tipMessage.add(S.of(context).model_fixture1_53);

            if (baseKey.keyClass == 10) {
              //平铣类型
              gifPath = appData.keyimagepath + "/fixture/model/1_5_5.gif";
              for (var i = 1; i < 4; i++) {
                imagePath.add("1_5_5_$i.png");
              }
            } else {
              //立铣类型 9
              gifPath = appData.keyimagepath + "/fixture/model/1_0_5.gif";
              for (var i = 1; i < 4; i++) {
                imagePath.add("1_0_5_$i.png");
              }
            }
          }
        } else {
          //旧家具
          if (baseKey.locat == 1) {
            tipMessage.add(S.of(context).model_fixture0_11);
            tipMessage.add(S.of(context).model_fixture0_12);
            tipMessage.add(S.of(context).model_fixture0_13);

            if (baseKey.keyClass == 10) {
              //平铣类型
              gifPath = appData.keyimagepath + "/fixture/model/0_5_3.gif";
              for (var i = 1; i < 4; i++) {
                imagePath.add("0_5_1_$i.png");
              }
            } else {
              //立铣类型 9
              gifPath = appData.keyimagepath + "/fixture/model/0_0_3.gif";
              for (var i = 1; i < 4; i++) {
                imagePath.add("0_0_1_$i.png");
              }
            }
          } else {
            tipMessage.add(S.of(context).model_fixture0_51);
            tipMessage.add(S.of(context).model_fixture0_52);
            tipMessage.add(S.of(context).model_fixture0_53);

            if (baseKey.keyClass == 10) {
              //平铣类型
              gifPath = appData.keyimagepath + "/fixture/model/0_5_5.gif";
              for (var i = 1; i < 4; i++) {
                imagePath.add("0_5_5_$i.png");
              }
            } else {
              //立铣类型 9
              gifPath = appData.keyimagepath + "/fixture/model/0_0_5.gif";
              for (var i = 1; i < 4; i++) {
                imagePath.add("0_0_5_$i.png");
              }
            }
          }
        }
        break;
      case 4:
        if (cnCversion.fixtureType == 21) {
          //新夹具
          if (baseKey.locat == 1) {
            tipMessage.add(S.of(context).model_fixture1_41);
            tipMessage.add(S.of(context).model_fixture1_42);
            tipMessage.add(S.of(context).model_fixture1_43);

            if (baseKey.keyClass == 10) {
              //平铣类型
              gifPath = appData.keyimagepath + "/fixture/model/1_5_6.gif";
              for (var i = 1; i < 4; i++) {
                imagePath.add("1_5_4_$i.png");
              }
            } else {
              //立铣类型 9
              gifPath = appData.keyimagepath + "/fixture/model/1_0_6.gif";
              for (var i = 1; i < 4; i++) {
                imagePath.add("1_0_4_$i.png");
              }
            }
          } else {
            tipMessage.add(S.of(context).model_fixture1_61);
            tipMessage.add(S.of(context).model_fixture1_62);
            tipMessage.add(S.of(context).model_fixture1_63);
            tipMessage.add(S.of(context).model_fixture1_64);

            if (baseKey.keyClass == 10) {
              //平铣类型
              gifPath = appData.keyimagepath + "/fixture/model/1_5_..gif";
              for (var i = 1; i < 5; i++) {
                imagePath.add("1_5_6_$i.png");
              }
            } else {
              //立铣类型 9
              gifPath = appData.keyimagepath + "/fixture/model/1_0_3.gif";
              for (var i = 1; i < 5; i++) {
                imagePath.add("1_0_6_$i.png");
              }
            }
          }
        } else {
          //旧家具
          if (baseKey.locat == 1) {
            tipMessage.add(S.of(context).model_fixture0_41);
            tipMessage.add(S.of(context).model_fixture0_42);
            tipMessage.add(S.of(context).model_fixture0_43);

            if (baseKey.keyClass == 10) {
              //平铣类型
              gifPath = appData.keyimagepath + "/fixture/model/0_5_3.gif";
              for (var i = 1; i < 4; i++) {
                imagePath.add("0_5_4_$i.png");
              }
            } else {
              //立铣类型 9
              gifPath = appData.keyimagepath + "/fixture/model/0_0_3.gif";
              for (var i = 1; i < 4; i++) {
                imagePath.add("0_0_4_$i.png");
              }
            }
          } else {
            tipMessage.add(S.of(context).model_fixture0_61);
            tipMessage.add(S.of(context).model_fixture0_62);
            tipMessage.add(S.of(context).model_fixture0_63);
            tipMessage.add(S.of(context).model_fixture0_64);

            if (baseKey.keyClass == 10) {
              //平铣类型
              gifPath = appData.keyimagepath + "/fixture/model/0_5_6.gif";
              for (var i = 1; i < 5; i++) {
                imagePath.add("0_5_6_$i.png");
              }
            } else {
              //立铣类型 9
              gifPath = appData.keyimagepath + "/fixture/model/0_0_6.gif";
              for (var i = 1; i < 5; i++) {
                imagePath.add("0_0_6_$i.png");
              }
            }
          }
        }
        break;
      case 5:
        temp.add(const Text("完成"));
        break;
    }
    for (var i = 0; i < imagePath.length; i++) {
      temp.add(Text(tipMessage[i]));
      temp.add(Image.file(
          File(appData.rootpath + "/image/fixture/model/" + imagePath[i])));
    }
    return temp;
  }

  Widget showwidget() {
    switch (side) {
      case 1:
        return Column(
          children: [
            Expanded(
                child: ListView(
              children: [Text("第$side面")],
            )),
            SizedBox(
                width: double.maxFinite,
                child: ElevatedButton(
                    onPressed: () {
                      //如果是首次切削需要发送切削数据
                      //否则发送继续命令
                      if (widget.arguments["first"]) {
                        List<int> temp = [];
                        temp.add(cncBtSmd.cutKeyModel);
                        temp.add(0);
                        temp.addAll(baseKey.creatkeydata(0));
                        sendCmd(temp);
                        Navigator.pushNamed(context, '/cutkeymodel');
                      } else {
                        sendCmd([0x9a, 0]);
                        Navigator.pushReplacementNamed(context, '/cutkeymodel');
                      }
                    },
                    child: const Text("继续")))
          ],
        );
      case 2:
        return Column(
          children: [
            Expanded(
                child: ListView(
              children: [Text("第$side面")],
            )),
            SizedBox(
                width: double.maxFinite,
                child: ElevatedButton(
                    onPressed: () {
                      if (widget.arguments["first"]) {
                        List<int> temp = [];
                        temp.add(cncBtSmd.cutKeyModel);
                        temp.add(0);
                        temp.addAll(baseKey.creatkeydata(0));
                        sendCmd(temp);
                        Navigator.pushNamed(context, '/cutkeymodel');
                      } else {
                        sendCmd([0x9a, 0]);
                        Navigator.pushReplacementNamed(context, '/cutkeymodel');
                      }
                    },
                    child: const Text("继续")))
          ],
        );
      case 3:
        return Column(
          children: [
            Expanded(
                child: ListView(
              children: [Text("第$side面")],
            )),
            SizedBox(
                width: double.maxFinite,
                child: ElevatedButton(
                    onPressed: () {
                      if (widget.arguments["first"]) {
                        List<int> temp = [];
                        temp.add(cncBtSmd.cutKeyModel);
                        temp.add(0);
                        temp.addAll(baseKey.creatkeydata(0));
                        sendCmd(temp);
                        Navigator.pushNamed(context, '/cutkeymodel');
                      } else {
                        sendCmd([0x9a, 0]);
                        Navigator.pushReplacementNamed(context, '/cutkeymodel');
                      }
                    },
                    child: const Text("继续")))
          ],
        );
      case 4:
        return Column(
          children: [
            Expanded(
                child: ListView(
              children: [Text("第$side面")],
            )),
            SizedBox(
                width: double.maxFinite,
                child: ElevatedButton(
                    onPressed: () {
                      if (widget.arguments["first"]) {
                        List<int> temp = [];
                        temp.add(cncBtSmd.cutKeyModel);
                        temp.add(0);
                        temp.addAll(baseKey.creatkeydata(0));
                        sendCmd(temp);
                        Navigator.pushNamed(context, '/cutkeymodel');
                      } else {
                        sendCmd([0x9a, 0]);
                        Navigator.pushReplacementNamed(context, '/cutkeymodel');
                      }
                    },
                    child: const Text("继续")))
          ],
        );
      case 5:
        return Column(children: [
          Expanded(
              child: ListView(
            children: const [Text("完成")],
          )),
          SizedBox(
              width: double.maxFinite,
              child: ElevatedButton(
                  onPressed: () {
                    // sendCmd([0x9a, 0]);
                    showDialog(
                        context: context,
                        builder: (c) {
                          return const MyTextDialog("是否再切一把？");
                        }).then((value) {
                      if (value) {
                        Navigator.pop(context);
                        widget.arguments["first"] = true;
                      } else {
                        Navigator.pop(context);
                        Navigator.pop(context);
                      }
                    });
                  },
                  child: const Text("完成")))
        ]);

      default:
        return Text("未处理的面$side");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
            child: ListView(
          children: clampkey(),
        )),
        Row(
          children: [
            SizedBox(
              width: 10.w,
            ),
            Expanded(
                child: ElevatedButton(
                    onPressed: () {
                      if (widget.arguments["first"]) {
                        List<int> temp = [];
                        temp.add(cncBtSmd.cutKeyModel);
                        temp.add(0);
                        temp.addAll(baseKey.creatkeydata(0));
                        sendCmd(temp);
                        Navigator.pushNamed(context, '/cutkeymodel');
                      } else {
                        sendCmd([0x9a, 0]);
                        Navigator.pushReplacementNamed(context, '/cutkeymodel');
                      }
                    },
                    child: const Text("继续"))),
            SizedBox(
              width: 10.w,
            ),
            Expanded(
                child: ElevatedButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/gifshow',
                          arguments: gifPath);
                    },
                    child: const Text("GIF"))),
            SizedBox(
              width: 10.w,
            ),
          ],
        ),
      ],
    );
  }
}
