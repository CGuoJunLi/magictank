import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';

import 'package:magictank/alleventbus.dart';
import 'package:magictank/appdata.dart';

import 'package:magictank/cncpage/bluecmd/cmd.dart';
import 'package:magictank/cncpage/bluecmd/receivecmd.dart';
import 'package:magictank/cncpage/bluecmd/share_manganger.dart';

CncBlutooth2Server cncbt2model = CncBlutooth2Server();

class CncBlutooth2Server {
  bool blSwitch = false;
  String btaddr = "";
  late BluetoothDevice device;
  int connect = 0;
  bool getserver = false;

  Timer? autoconnecttimer;
  Duration autoconnecttimeout = const Duration(seconds: 10);
  BluetoothConnection? connectdev;
  BluetoothDevice? bluetoothDevice;
  // late Guid uuid;
  // late DeviceIdentifier deviceId;
  // late Guid serviceUuid;
  // late Guid? secondaryServiceUuid;
  // late CharacteristicProperties properties;
  // late List<BluetoothDescriptor> descriptors;

  Future<void> connection(BluetoothDevice server) async {
    bluetoothDevice = server;
    if (connectdev != null) await connectdev!.close(); //断开上一次的连接
    await BluetoothConnection.toAddress(server.address).then((_connection) {
      connectdev = _connection;
      cncbtmodel.btaddr = server.address;
      connectdev!.input!.listen(_onDataReceived).onDone(() {
        // print("断开连接");
        cncbtmodel.state = false;
        //   Fluttertoast.showToast(msg: "蓝牙已断开");
        eventBus.fire(CNCConnectEvent(false));
        // Example: Detect which side closed the connection
        // There should be `isDisconnecting` flag to show are we are (locally)
        // in middle of disconnecting process, should be set before calling
        // `dispose`, `finish` or `close`, which all causes to disconnect.
        // If we except the disconnection, `onDone` should be fired as result.
        // If we didn't except this (no flag set), it means closing by remote.
      });
      // return true;
    }).catchError((error) {
      ////print('Cannot connect, exception occured');
      ////print(error);
      //return false;
      eventBus.fire(CNCConnectEvent(false));
      // return false;
    });
    eventBus.fire(CNCConnectEvent(true));
    getver();
//  return true;
    // return false;
  }

  void _onDataReceived(Uint8List data) {
    // Allocate buffer for parsed data
    // int backspacesCounter = 0;
    //debugPrint("chat");
    //receivedata = data;
    debugPrint("收到数据");
    procesData(data);
  }

  Future<void> senddata(List<int> value) async {
    try {
      connectdev!.output.add(Uint8List.fromList(value));
      await connectdev!.output.allSent;
    } catch (e) {
      // Ignore error, but notify state
      debugPrint("发送出错了");
    }
  }

  void disconnect() async {
    try {
      connectdev!.close();
    } catch (e) {
      debugPrint("$e");
    }
  }

  ///自动连接
  Future<void> autoConnect() async {
    debugPrint("BL2连接的蓝牙名称是：${appData.cncbluetoothname}");
    if (appData.cncbluetoothname != "") {
      //bool searchbt = false;
      late StreamSubscription _streamSubscription;
      List<BluetoothDiscoveryResult> results =
          List<BluetoothDiscoveryResult>.empty(growable: true);
      autoconnecttimer = Timer(autoconnecttimeout, () async {
        if (!getCncBtState()) {
          debugPrint("超时取消连接");
          bool? scan = await FlutterBluetoothSerial.instance.isDiscovering;
          if (scan!) {
            FlutterBluetoothSerial.instance.cancelDiscovery();
          }
          _streamSubscription.cancel();
          disconnect();
          eventBus.fire(CNCConnectEvent(false));
        }
      });
      _streamSubscription =
          FlutterBluetoothSerial.instance.startDiscovery().listen((r) {
        final existingIndex = results.indexWhere(
            (element) => element.device.address == r.device.address);
        if (existingIndex >= 0) {
          results[existingIndex] = r;
        } else {
          //名字长度==16 才算是 数控机
          if (r.device.name != null) {
            if (r.device.address == appData.cncbluetoothname) {
              //searchbt = true;
              connection(r.device);
            }
          }
        }
      });

      // _streamSubscription.onDone(() {
      //   if (!searchbt) {
      //     eventBus.fire(CNCConnectEvent(false));
      //   }
      // });
    }
  }
}
