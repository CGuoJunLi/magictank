/*
使用方法
配置好环境： 
Android/iOS 权限设置完毕
导入库 flutter_blue 
1.初始化
initBle();
2.开始搜索蓝牙设备
startBle();
3.得到搜索到所有蓝牙设备名字数组(含名称过滤/空名、错误名)
getBleScanNameAry
4.从名字数组里面选择对应的蓝牙设备进行连接，传入需要连接的设备名在数组的位置
(其实是假连接，停止扫描，准备好需要连接的蓝牙设备参数)
connectionBle(int chooseBle)
5.正式连接蓝牙，并且开始检索特征描述符，并匹配需要用到的特征描述符等
discoverServicesBle()
6.断开蓝牙连接
endBle()
*写入数据  例子：dataCallsendBle([0x00, 0x00, 0x00, 0x00])
dataCallsendBle(List<int> value)
*收到数据
dataCallbackBle()
更多帮助博客：https://www.jianshu.com/p/bab40d5ecdee
*/

//import 'package:archive/archive.dart';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_blue/flutter_blue.dart';
import 'dart:async';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:magictank/alleventbus.dart';
import 'package:magictank/appdata.dart';
import 'package:magictank/bluetooth/btmodel.dart';

import 'package:magictank/cncpage/bluecmd/cmd.dart';
import 'package:magictank/cncpage/bluecmd/receivecmd.dart';
import 'package:magictank/cncpage/bluecmd/share_manganger.dart';

CncBlutooth4Server cncbt4model = CncBlutooth4Server();

class CncBlutooth4Server {
  bool state = false;
  bool blSwitch = false;
  String btaddr = "";
  FlutterBlue flutterBlue = FlutterBlue.instance;
  late BluetoothDevice device;
  int connect = 0;
  bool getserver = false;
  ScanResult? result;
  BluetoothCharacteristic? sendmCharacteristic;
  BluetoothCharacteristic? receivemCharacteristic;
  StreamSubscription? _streamSubscriptionData;
  StreamSubscription? _streamSubscriptionState;
  Timer? autoconnecttimer;
  Duration autoconnecttimeout = const Duration(seconds: 10);
  // late Guid uuid;
  // late DeviceIdentifier deviceId;
  // late Guid serviceUuid;
  // late Guid? secondaryServiceUuid;
  // late CharacteristicProperties properties;
  // late List<BluetoothDescriptor> descriptors;
  init() {
    sendmCharacteristic = null;
    receivemCharacteristic = null;
  }

  void connection(BluetoothDevice connectDevice) async {
    if (autoconnecttimer != null) {
      autoconnecttimer!.cancel();
    }
    flutterBlue.stopScan();
    try {
      disconnect();
    } catch (e) {
      debugPrint("$e");
    }
    debugPrint("准备连接");
    device = connectDevice;
    try {
      if (_streamSubscriptionData != null) {
        _streamSubscriptionData!.cancel();
      }
    } catch (e) {
      debugPrint("取消失败");
    }
    runZonedGuarded(() async {
      // var connectedDevices;
      // connectedDevices = await flutterBlue.connectedDevices;
      // for (int i = 0; i < connectedDevices.length; i++) {
      //   connectedDevices[i].disconnect();
      // }
      await device.connect(
          autoConnect: false, timeout: const Duration(seconds: 10));
      listenbtstate();

      //timer!.cancel();
      //等待设置mtu
      if (!Platform.isIOS) {
        //ios不需要协商MTU
        await device.requestMtu(512);
        await Future.delayed(const Duration(seconds: 1));
      }

      debugPrint("连接成功");
      // device.discoverServices().then((value) {

      // }).onError((error, stackTrace) => null);
      debugPrint("执行 UUID1");

      List<BluetoothService> services = await device.discoverServices();

      debugPrint("执行 UUID");

      for (var service in services) {
        //新版本蓝牙

        if (service.uuid.toString() == "0000ffe0-0000-1000-8000-00805f9b34fb") {
          List<BluetoothCharacteristic> characteristics =
              service.characteristics;

          for (var characteristic in characteristics) {
            if (characteristic.uuid.toString() ==
                "0000ffe1-0000-1000-8000-00805f9b34fb") {
              debugPrint("匹配到正确的接收特征值");
              receivemCharacteristic = characteristic;
            }
            if (characteristic.uuid.toString() ==
                    "0000ffe1-0000-1000-8000-00805f9b34fb"
                //"49535343-8841-43f4-a8d4-ecbe34729bb3"
                ) {
              debugPrint("匹配到正确的发送特征值");
              sendmCharacteristic = characteristic;
            }
          }
        }
        //旧版本蓝牙
        // if (service.uuid.toString().toUpperCase() ==
        //     "49535343-FE7D-4AE5-8FA9-9FAFD205E455") {
        //   List<BluetoothCharacteristic> characteristics =
        //       service.characteristics;
        //   for (var characteristic in characteristics) {
        //     print(characteristic.uuid.toString().toUpperCase());
        //     if (characteristic.uuid.toString().toUpperCase() ==
        //         "49535343-1E4D-4BD9-BA61-23C647249616") {
        //       debugPrint("匹配到正确的接收特征值");
        //       receivemCharacteristic = characteristic;
        //     }
        //     if (characteristic.uuid.toString().toUpperCase() ==
        //             "49535343-8841-43F4-A8D4-ECBE34729BB3"
        //         //"49535343-8841-43f4-a8d4-ecbe34729bb3"
        //         ) {
        //       debugPrint("匹配到正确的发送特征值");
        //       sendmCharacteristic = characteristic;
        //     }
        //   }
        // }
      }
      debugPrint("准备接收数据");
      await receivemCharacteristic!.setNotifyValue(true);
      _streamSubscriptionData = receivemCharacteristic!.value.listen((value) {
        debugPrint("收到数据");
        debugPrint("$value");
        if (value.isNotEmpty) {
          procesData(value);
        }
      });

      eventBus.fire(CNCConnectEvent(true));
      cncbtmodel.state = true;
      getver();

      // progressChip.getver();
    }, (Object error, StackTrace stack) async {
      debugPrint("蓝牙出错了");
      cncbtmodel.state = false;
      debugPrint("$error");
      disconnect();
      eventBus.fire(CNCConnectEvent(false));
    });
  }

  Future<void> senddata(List<int> value) async {
    await sendmCharacteristic!.write(value);
  }

  bool getBtState() {
    return state;
  }

  void listenbtstate() {
    _streamSubscriptionState = device.state.listen((event) {
      if (event == BluetoothDeviceState.disconnected ||
          event == BluetoothDeviceState.disconnecting) {
        connect = 0;
        state = false;
        _streamSubscriptionState!.cancel();
        eventBus.fire(CNCConnectEvent(false));
        Fluttertoast.showToast(msg: "蓝牙断开");
      }
      if (event == BluetoothDeviceState.connected) {
        connect = 1;
      }
      if (event == BluetoothDeviceState.connecting) {
        connect = 2;
      }
    });
  }

  void disconnect() async {
    state = false;
    try {
      await device.disconnect();
    } catch (e) {
      debugPrint("$e");
    }
    // eventBus.fire(BTStateEvent(false));
  }

  ///自动连接
  Future<void> autoConnect() async {
    //如果蓝牙已打
    late StreamSubscription _streamSubscriptionDrive;
    await flutterBlue.stopScan();
    await flutterBlue.startScan(timeout: const Duration(seconds: 8));
    // 监听扫描结果

    autoconnecttimer = Timer(autoconnecttimeout, () {
      if (!getBtState()) {
        debugPrint("超时取消连接");
        _streamSubscriptionDrive.cancel();
        disconnect();
        eventBus.fire(CNCConnectEvent(false));
      }
    });
    _streamSubscriptionDrive = flutterBlue.scanResults.listen((results) {
      // 扫描结果 可扫描到的所有蓝牙设备
      for (ScanResult r in results) {
        debugPrint(r.device.id.toString());
        debugPrint(appData.bluetoothname);

        if (r.device.id.toString().toUpperCase() ==
            appData.bluetoothname.toUpperCase()) {
          flutterBlue.stopScan();
          debugPrint("取消扫描");
          _streamSubscriptionDrive.cancel();
          result = r;
          connection(r.device);
          break;
        }
      }
    });
  }
}
