import 'dart:convert';

import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter_blue/flutter_blue.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:magictank/alleventbus.dart';
import 'package:magictank/appdata.dart';
import 'package:magictank/bluetooth/bluetooth_switch.dart';
import 'package:magictank/cncpage/bluecmd/share_manganger.dart';
import 'package:magictank/generated/l10n.dart';
import 'package:magictank/userappbar.dart';
import 'package:sn_progress_dialog/progress_dialog.dart';
import 'dart:async';

//import 'package:bluetooth_enable_fork/bluetooth_enable_fork.dart';
import 'cncbt4_manganger.dart';

//import 'enable_bluetooth.dart';

class SeleCncBT4Page extends StatefulWidget {
  final int machineType;
  const SeleCncBT4Page(this.machineType, {Key? key}) : super(key: key);
  @override
  _SeleCncPageState createState() => _SeleCncPageState();
}

class _SeleCncPageState extends State<SeleCncBT4Page> {
  bool scanstates = false;
  late ProgressDialog pd;
  Timer? timer;
  //bool btstate = false;
  late StreamSubscription btStateEvent;
  Future<void> enableBT() async {
    BluetoothEnable.enableBluetooth.then((value) {
      debugPrint("value:" + value);
      setState(() async {
        if (value == "true") {
          cncbtmodel.blSwitch = true;
          await Future.delayed(const Duration(seconds: 3));
          beginscanbt();
        }
      });
    });
  }

  Future<void> disenableBT() async {
    BluetoothEnable.disableBluetooth.then((value) {
      debugPrint(value);
    });
  }

  @override
  void dispose() {
    super.dispose();
    btStateEvent.cancel();
  }

  @override
  void initState() {
    //listenbtstate();
    pd = ProgressDialog(context: context);
//  _streamSubscriptionState =
    btStateEvent = eventBus.on<CNCConnectEvent>().listen(
      (CNCConnectEvent event) {
        setState(() {
          if (event.state) {
            pd.close();

            debugPrint(cncbt4model.device.id.toString());

            appData.upgradeAppData(
                {"bluetoothname": cncbt4model.device.id.toString()});

            btStateEvent.cancel();
            cncbtmodel.state = true;
            Navigator.pop(context);
          } else {
            cncbt4model.disconnect();
            pd.close();
            Fluttertoast.showToast(msg: S.of(context).btconnetcerror);
          }
        });
      },
    );

    if (cncbtmodel.blSwitch) {
      beginscanbt();
    }
    //beginscanbt(); //监听蓝牙扫描状态
    //ConnectBL(); //获取连接到的蓝牙列表
    super.initState();
  }

  Future<void> beginscanbt() async {
    await cncbt4model.flutterBlue.stopScan();
    cncbt4model.flutterBlue.startScan(timeout: const Duration(seconds: 10));
  }

  bool selebttype(ScanResult result) {
    appData.machineType = 3;
    String btnamemd5 = "MAGIC TANK" + result.device.id.toString();
    Uint8List content = const Utf8Encoder().convert(btnamemd5);
    Digest digest = md5.convert(content);
    btnamemd5 = base64.encode(digest.bytes);
    // print("$btnamemd5,${result.device.name}");
    if (result.device.name.contains(btnamemd5.substring(0, 7))) {
      return true;
    } else {
      if (appData.limit == 10) {
        if (result.device.name == "UN_NAME") {
          return true;
        } else {
          return false;
        }
      }
      return false;
    }
  }

  Widget bltitle(ScanResult result) {
    return selebttype(result)
        //result.device.name.length == 16
        ? Card(
            child: StreamBuilder<BluetoothDeviceState>(
              stream: result.device.state,
              initialData: BluetoothDeviceState.connecting,
              builder: (c, snapshot) {
                VoidCallback? onPressed;
                String text;
                switch (snapshot.data) {
                  case BluetoothDeviceState.connected:
                    onPressed = () {
                      result.device.disconnect();
                      // disconnect();
                    };
                    text = '断开连接';
                    break;
                  case BluetoothDeviceState.disconnected:
                    onPressed = () {
                      pd.show(max: 100, msg: S.of(context).btconnecting);
                      cncbt4model.connection(result.device);

                      // result.device.
                      // result.device.connect(timeout: Duration(S))
                    };
                    text = '连接';
                    break;
                  default:
                    onPressed = null;
                    text = snapshot.data.toString().substring(21).toUpperCase();
                    break;
                }
                return TextButton(
                  onPressed: onPressed,
                  child: SizedBox(
                    height: 50.h,
                    child: Row(
                      children: [
                        const Icon(Icons.computer),
                        const Expanded(child: SizedBox()),
                        Column(
                          children: [
                            Text(result.device.name.isNotEmpty
                                ? result.device.name
                                : result.device.id.toString()),
                            Text(result.device.id.toString()),
                          ],
                        ),
                        const Expanded(child: SizedBox()),
                        Text(text),
                      ],
                    ),
                  ),
                );
              },
            ),
          )
        : Container();
  }

  List<Widget> bllist(List<ScanResult> snapshot) {
    List<Widget> temp = [];

    //snapshot[i].device.name == "magiclcone" ||
    for (var i = 0; i < snapshot.length; i++) {
      if (snapshot[i].device.name.length > 1) {
        temp.add(Card(
          child: TextButton(
            child: Stack(
              children: [
                Align(
                  child: Text(snapshot[i].device.name),
                  alignment: Alignment.centerLeft,
                ),
                const Align(
                  child: Text("连接设备"),
                  //child: Text("连接"),
                  alignment: Alignment.centerRight,
                ),
              ],
            ),
            onPressed: () {
              setState(() {
                cncbt4model.connection(snapshot[i].device);
              });
            },
          ),
        ));
      }
    }

    return temp;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: userAppBar(),
      body: Column(
        children: [
          const Divider(),
          SizedBox(
            height: 20.h,
            child: Stack(
              children: [
                Align(
                  child: Text(S.of(context).btswicth),
                  alignment: Alignment.centerLeft,
                ),
                Align(
                  child: Switch(
                    onChanged: (bool value) {
                      setState(() {
                        if (Platform.isAndroid) {
                          cncbtmodel.blSwitch = value;
                          if (value) {
                            enableBT();
                          } else {
                            //  FlutterBlue.instance.stopScan();
                            cncbt4model.disconnect();
                            disenableBT();
                          }
                        }
                      });

                      debugPrint("$value");
                    },
                    value: cncbtmodel.blSwitch,
                  ),
                  alignment: Alignment.centerRight,
                ),
              ],
            ),
          ),
          const Divider(),
          SizedBox(
            height: 20.h,
            child: Stack(
              children: [
                Align(
                  child: Text(S.of(context).autoconnectbt),
                  alignment: Alignment.centerLeft,
                ),
                Align(
                  child: Switch(
                    onChanged: (bool value) {
                      debugPrint("$value");
                      appData.autoconnect = value;
                      appData.upgradeAppData({"autoconnect": value});
                      setState(() {});
                    },
                    value: appData.autoconnect,
                  ),
                  alignment: Alignment.centerRight,
                ),
              ],
            ),
          ),
          const Divider(),
          Expanded(
            child: cncbtmodel.blSwitch
                ? RefreshIndicator(
                    onRefresh: () {
                      debugPrint("下拉刷新");

                      return beginscanbt();
                    },
                    child: StreamBuilder<List<ScanResult>>(
                      stream: cncbt4model.flutterBlue.scanResults,
                      initialData: const [],
                      builder: (c, snapshot) => ListView(
                        children: snapshot.data!
                            .map(
                              (r) => bltitle(
                                r,
                              ),
                            )
                            .toList(),
                      ),
                    ),
                  )
                : Text(S.of(context).needbtopen),
          ),
          Text(
            S.of(context).btrefresh,
            style: const TextStyle(color: Colors.red),
          ),
        ],
      ),
    );
  }
}
