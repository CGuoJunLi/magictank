import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:magictank/appdata.dart';
import 'package:magictank/cncpage/bluecmd/cmd.dart';
import 'package:magictank/cncpage/bluecmd/receivecmd.dart';
import 'package:magictank/cncpage/bluecmd/sendcmd.dart';
import 'package:magictank/cncpage/createkeydata.dart';
import 'package:magictank/generated/l10n.dart';

class ClampState {
  static const continues = 0;
}

class OpenClampPage extends StatefulWidget {
  final Map arguments;
  const OpenClampPage(
    this.arguments, {
    Key? key,
  }) : super(key: key);
  @override
  _OpenClampPageState createState() => _OpenClampPageState();
}

class _OpenClampPageState extends State<OpenClampPage> {
  // Map keydata = {};
  List<String> title = [];
  List<String> image = [];
  String gifPath = "";
  bool dir = false;

  @override
  void initState() {
    if (widget.arguments["dir"] != null) {
      dir = widget.arguments["dir"];
      if (dir) {
        SystemChrome.setPreferredOrientations(
            [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
        //设置状态栏隐藏
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
            overlays: [SystemUiOverlay.top]);
      }
    }

    // keydata = Map.from(widget.arguments["keydata"]);
    // getListTitle();
    ////print(keydata);
    // initListTitle();
    super.initState();
  }

  List<Widget> keyclampviewlist() {
    List<Widget> temp = [];
    //fixture 根据夹具类型显示图片
    //class  根据钥匙类型显示图片
    //id  根据钥匙ID显示图片
    title = [];
    image = [];
    int count = 0;
    gifPath = appData.keyimagepath + "/fixture/1_1_1.gif";
    switch (baseKey.fixture) {
      case 0: //左侧夹块
      case 4:
      case 3:
        //如果是新夹具
        if (cnCversion.fixtureType == 21) {
          //选择需要显示的gif
          switch (baseKey.keySerNum) {
            case 70: //hu64
            case 177:
            case 178:
            case 901:
              if (widget.arguments["side"] == 2) {
                gifPath = appData.keyimagepath + "/fixture/1_hu64b.gif";
              } else {
                gifPath = appData.keyimagepath + "/fixture/1_hu64a.gif";
              }
              break;
            case 65:
              gifPath = appData.keyimagepath + "/fixture/1_hu101.gif";
              break;
            case 158:
            case 159:
            case 242:
              if (widget.arguments["side"] == 2) {
                gifPath = appData.keyimagepath + "/fixture/1_huhu162ta2.gif";
              } else {
                gifPath = appData.keyimagepath + "/fixture/1_huhu162ta1.gif";
              }
              break;
            case 510:
              gifPath = appData.keyimagepath + "/fixture/1_huhu162tb.gif";
              break;
            case 511:
              gifPath = appData.keyimagepath + "/fixture/1_huhu162tc.gif";
              break;
            default:
              if (baseKey.locat == 1) {
                gifPath = appData.keyimagepath + "/fixture/1_0_1.gif";
              } else {
                gifPath = appData.keyimagepath + "/fixture/1_0_0.gif";
              }
              break;
          }

          if (!baseKey.smartkey) {
            if (!baseKey.nonconductive) {
              if (baseKey.locat == 0) {
                //对肩膀
                title.add(S.of(context).key_working_2_11);
                title.add(S.of(context).key_working_2_21);
                title.add(S.of(context).key_working_2_31);
                title.add(S.of(context).key_working_2_41);
                for (var i = 1; i < 5; i++) {
                  image.add("1_0_0_$i.png");
                }
              } else {
                //对头
                title.add(S.of(context).key_working_1_11);
                title.add(S.of(context).key_working_1_21);
                title.add(S.of(context).key_working_1_31);
                for (var i = 1; i < 4; i++) {
                  image.add("1_0_1_$i.png");
                }
              }
            } else {
              if (baseKey.locat == 0) {
                //对肩膀
                title.add(S.of(context).key_working_1_11);
                title.add(S.of(context).key_working_1_21);
                title.add(S.of(context).key_working_1_31);
                for (var i = 1; i < 4; i++) {
                  image.add("1_0_1_$i.png");
                }
              } else {
                title.add("非导电钥匙");
                title.add(S.of(context).key_dia_title4);
                title.add(S.of(context).key_working_1_31);
                for (var i = 1; i < 4; i++) {
                  image.add("insulations/1_0_1_$i.png");
                }
              }
            }
          } else {
            //智能卡类钥匙图片
            switch (baseKey.keySerNum) {
              case 65: //HU101
                if (widget.arguments["side"] == 2) //第二面反夹
                {
                  gifPath =
                      appData.keyimagepath + "/fixture/smart/1_hu101b.gif";
                  title.add(S.of(context).key_working_2_11);
                  title.add(S.of(context).key_working_2_21);
                  title.add(S.of(context).key_working_2_31);
                  title.add(S.of(context).key_working_2_41);
                  for (var i = 1; i < 4; i++) {
                    image.add("smart/1_hu101_${i + 3}.png");
                  }
                } else {
                  gifPath =
                      appData.keyimagepath + "/fixture/smart/1_hu101a.gif";
                  title.add(S.of(context).key_working_2_11);
                  title.add(S.of(context).key_working_2_21);
                  title.add(S.of(context).key_working_2_31);
                  title.add(S.of(context).key_working_2_41);
                  for (var i = 1; i < 4; i++) {
                    image.add("smart/1_hu101_$i.png");
                  }
                }
                break;

              case 158:
              case 159:
                if (widget.arguments["side"] == 2) //
                {
                  gifPath =
                      appData.keyimagepath + "/fixture/smart/1_hu162ta2.gif";
                  title.add(S.of(context).key_working_2_11);
                  title.add(S.of(context).key_working_2_21);
                  title.add(S.of(context).key_working_2_31);
                  title.add(S.of(context).key_working_2_41);
                  for (var i = 1; i < 4; i++) {
                    image.add("smart/1_hu162ta_${i + 3}.png");
                  }
                } else {
                  gifPath =
                      appData.keyimagepath + "/fixture/smart/1_hu162ta1.gif";
                  title.add(S.of(context).key_working_2_11);
                  title.add(S.of(context).key_working_2_21);
                  title.add(S.of(context).key_working_2_31);
                  title.add(S.of(context).key_working_2_41);
                  for (var i = 1; i < 4; i++) {
                    image.add("smart/1_hu162ta_$i.png");
                  }
                }
                break;
              case 510:
                gifPath = appData.keyimagepath + "/fixture/smart/1_hu162tb.gif";
                title.add(S.of(context).key_working_2_11);
                title.add(S.of(context).key_working_2_21);
                title.add(S.of(context).key_working_2_31);
                title.add(S.of(context).key_working_2_41);
                for (var i = 1; i < 4; i++) {
                  image.add("smart/1_hu162tb_$i.png");
                }
                break;
              case 511:
                gifPath = appData.keyimagepath + "/fixture/smart/1_hu162tc.gif";
                title.add(S.of(context).key_working_2_11);
                title.add(S.of(context).key_working_2_21);
                title.add(S.of(context).key_working_2_31);
                title.add(S.of(context).key_working_2_41);
                for (var i = 1; i < 4; i++) {
                  image.add("smart/1_hu162tc_$i.png");
                }
                break;
              default:
                if (widget.arguments["side"] == 2) //第二面反夹
                {
                  gifPath = appData.keyimagepath + "/fixture/smart/1_0_1b.gif";
                  title.add(S.of(context).key_working_2_11);
                  title.add(S.of(context).key_working_2_21);
                  title.add(S.of(context).key_working_2_31);
                  title.add(S.of(context).key_working_2_41);
                  for (var i = 1; i < 4; i++) {
                    image.add("smart/1_0_1_${i + 3}.png");
                  }
                } else {
                  gifPath = appData.keyimagepath + "/fixture/smart/1_0_1a.gif";
                  title.add(S.of(context).key_working_2_11);
                  title.add(S.of(context).key_working_2_21);
                  title.add(S.of(context).key_working_2_31);
                  title.add(S.of(context).key_working_2_41);
                  for (var i = 1; i < 4; i++) {
                    image.add("smart/1_0_1_$i.png");
                  }
                }
                break;
            }
          }
        } else {
          //旧夹具图片
          switch (baseKey.keySerNum) {
            case 70:
            case 177:
            case 178:
            case 901:
              if (widget.arguments["side"] == 2) {
                gifPath = appData.keyimagepath + "/fixture/1_hu64b.gif";
              } else {
                gifPath = appData.keyimagepath + "/fixture/1_hu64a.gif";
              }
              break;
            case 65:
              gifPath = appData.keyimagepath + "/fixture/1_hu101.gif";
              break;
            case 158:
            case 159:
            case 242:
              if (widget.arguments["side"] == 2) {
                gifPath = appData.keyimagepath + "/fixture/1_huhu162ta2.gif";
              } else {
                gifPath = appData.keyimagepath + "/fixture/1_huhu162ta1.gif";
              }
              break;
            case 510:
              gifPath = appData.keyimagepath + "/fixture/1_huhu162tb.gif";
              break;
            case 511:
              gifPath = appData.keyimagepath + "/fixture/1_huhu162tc.gif";
              break;
            default:
              if (baseKey.locat == 1) {
                gifPath = appData.keyimagepath + "/fixture/1_0_1.gif";
              } else {
                gifPath = appData.keyimagepath + "/fixture/1_0_0.gif";
              }
              break;
          }
          if (!baseKey.smartkey) {
            if (cnCversion.fixtureType == 21) {
              if (baseKey.locat == 0) {
                //对肩膀
                title.add(S.of(context).key_working_2_11);
                title.add(S.of(context).key_working_2_21);
                title.add(S.of(context).key_working_2_31);
                title.add(S.of(context).key_working_2_41);
                for (var i = 1; i < 5; i++) {
                  image.add("1_0_0_$i.png");
                }
              } else {
                //对头
                title.add(S.of(context).key_working_1_11);
                title.add(S.of(context).key_working_1_21);
                title.add(S.of(context).key_working_1_31);
                for (var i = 1; i < 4; i++) {
                  image.add("1_0_1_$i.png");
                }
              }
            } else {
              if (baseKey.locat == 0) {
                //对肩膀
                title.add(S.of(context).key_working_2_11);
                title.add(S.of(context).key_working_2_21);
                title.add(S.of(context).key_working_2_31);
                title.add(S.of(context).key_working_2_41);
                for (var i = 1; i < 5; i++) {
                  image.add("0_0_$i.png");
                }
              } else {
                //对头
                title.add(S.of(context).key_working_1_11);
                title.add(S.of(context).key_working_1_21);
                title.add(S.of(context).key_working_1_31);
                for (var i = 1; i < 4; i++) {
                  image.add("0_1_$i.png");
                }
              }
            }
          } else {
            //智能卡类钥匙图片
            switch (baseKey.keySerNum) {
              case 65: //HU101
                if (widget.arguments["side"] == 2) //第二面反夹
                {
                  gifPath =
                      appData.keyimagepath + "/fixture/smart/1_hu101b.gif";
                  title.add(S.of(context).key_working_2_11);
                  title.add(S.of(context).key_working_2_21);
                  title.add(S.of(context).key_working_2_31);
                  title.add(S.of(context).key_working_2_41);
                  for (var i = 1; i < 4; i++) {
                    image.add("smart/1_hu101_${i + 3}.png");
                  }
                } else {
                  gifPath =
                      appData.keyimagepath + "/fixture/smart/1_hu101a.gif";
                  title.add(S.of(context).key_working_2_11);
                  title.add(S.of(context).key_working_2_21);
                  title.add(S.of(context).key_working_2_31);
                  title.add(S.of(context).key_working_2_41);
                  for (var i = 1; i < 4; i++) {
                    image.add("smart/1_hu101_$i.png");
                  }
                }
                break;

              case 158:
              case 159:
                if (widget.arguments["side"] == 2) //
                {
                  gifPath =
                      appData.keyimagepath + "/fixture/smart/1_hu162ta2.gif";
                  title.add(S.of(context).key_working_2_11);
                  title.add(S.of(context).key_working_2_21);
                  title.add(S.of(context).key_working_2_31);
                  title.add(S.of(context).key_working_2_41);
                  for (var i = 1; i < 4; i++) {
                    image.add("smart/1_hu162ta_${i + 3}.png");
                  }
                } else {
                  gifPath =
                      appData.keyimagepath + "/fixture/smart/1_hu162ta1.gif";
                  title.add(S.of(context).key_working_2_11);
                  title.add(S.of(context).key_working_2_21);
                  title.add(S.of(context).key_working_2_31);
                  title.add(S.of(context).key_working_2_41);
                  for (var i = 1; i < 4; i++) {
                    image.add("smart/1_hu162ta_$i.png");
                  }
                }
                break;
              case 510:
                gifPath = appData.keyimagepath + "/fixture/smart/1_hu162tb.gif";
                title.add(S.of(context).key_working_2_11);
                title.add(S.of(context).key_working_2_21);
                title.add(S.of(context).key_working_2_31);
                title.add(S.of(context).key_working_2_41);
                for (var i = 1; i < 4; i++) {
                  image.add("smart/1_hu162tb_$i.png");
                }
                break;
              case 511:
                gifPath = appData.keyimagepath + "/fixture/smart/1_hu162tc.gif";
                title.add(S.of(context).key_working_2_11);
                title.add(S.of(context).key_working_2_21);
                title.add(S.of(context).key_working_2_31);
                title.add(S.of(context).key_working_2_41);
                for (var i = 1; i < 4; i++) {
                  image.add("smart/1_hu162tc_$i.png");
                }
                break;
              default:
                if (widget.arguments["side"] == 2) //第二面反夹
                {
                  gifPath = appData.keyimagepath + "/fixture/smart/1_0_1b.gif";
                  title.add(S.of(context).key_working_2_11);
                  title.add(S.of(context).key_working_2_21);
                  title.add(S.of(context).key_working_2_31);
                  title.add(S.of(context).key_working_2_41);
                  for (var i = 1; i < 4; i++) {
                    image.add("smart/1_0_1_${i + 3}.png");
                  }
                } else {
                  gifPath = appData.keyimagepath + "/fixture/smart/1_0_1a.gif";
                  title.add(S.of(context).key_working_2_11);
                  title.add(S.of(context).key_working_2_21);
                  title.add(S.of(context).key_working_2_31);
                  title.add(S.of(context).key_working_2_41);
                  for (var i = 1; i < 4; i++) {
                    image.add("smart/1_0_1_$i.png");
                  }
                }
                break;
            }
          }
        }
        break;
      case 2: //奔驰小夹具

        if (cnCversion.fixtureType == 21) {
          //新夹具
          if (widget.arguments["side"] == 2) {
            gifPath = appData.keyimagepath + "/fixture/1_hu64b.gif";
          } else {
            gifPath = appData.keyimagepath + "/fixture/1_hu64a.gif";
          }
          title.add(S.of(context).key_working_1_11);
          title.add(S.of(context).key_working_1_21);
          title.add(S.of(context).key_working_1_31);
          for (var i = 1; i < 4; i++) {
            image.add("1_hu64_$i.png");
          }
        } else {
          if (widget.arguments["side"] == 2) {
            gifPath = appData.keyimagepath + "/fixture/0_hu64b.gif";
          } else {
            gifPath = appData.keyimagepath + "/fixture/0_hu64a.gif";
          }
          title.add(S.of(context).key_working_1_11);
          title.add(S.of(context).key_working_1_21);
          title.add(S.of(context).key_working_1_31);
          title.add(S.of(context).key_working_1_11);
          title.add(S.of(context).key_working_1_21);
          title.add(S.of(context).key_working_1_31);
          for (var i = 1; i < 6; i++) {
            image.add("0_hu64_$i.png");
          }
        }
        break;
      case 1: //民用钥匙  只有新夹具

        gifPath = appData.keyimagepath + "/fixture/1_1_0.gif";

        title.add(S.of(context).user_11);
        title.add(S.of(context).user_21);
        title.add(S.of(context).user_31);
        title.add(S.of(context).user_41);
        title.add(S.of(context).user_51);
        title.add(S.of(context).user_61);
        title.add(S.of(context).user_71);
        title.add(S.of(context).user_81);
        title.add(S.of(context).user_91);
        for (var i = 1; i < 10; i++) {
          image.add("1_1_1_$i.png");
        }
        break;
      case 5: //右侧夹块
        if (cnCversion.fixtureType == 21) {
          switch (baseKey.keySerNum) {
            case 785: //TOY2
              gifPath = appData.keyimagepath + "/fixture/1_toy2.gif";
              break;
            case 22: //SX9A
              gifPath = appData.keyimagepath + "/fixture/1_sx9a.gif";
              break;
            case 21: //SX9B
              gifPath = appData.keyimagepath + "/fixture/1_sx9b.gif";
              break;
            case 822: //bw9te
              gifPath = appData.keyimagepath + "/fixture/1_bw9te.gif";
              break;
            case 831:
            case 878:
              gifPath = appData.keyimagepath + "/fixture/1_tata.gif";
              break;
            default:
              if (baseKey.locat == 1) {
                //对头类钥匙
                switch (baseKey.keyClass) {
                  case 0: //平铣双边
                    gifPath = appData.keyimagepath + "/fixture/1_50_1.gif";
                    break;
                  case 1: //平铣单边
                    gifPath = appData.keyimagepath + "/fixture/1_51_1.gif";
                    break;
                  default: //立铣类型
                    gifPath = appData.keyimagepath + "/fixture/1_54_1.gif";
                    break;
                }
              } else {
                //对肩膀
                switch (baseKey.keyClass) {
                  case 0: //平铣双边
                    gifPath = appData.keyimagepath + "/fixture/1_50_0.gif";
                    break;
                  case 1: //平铣单边
                    gifPath = appData.keyimagepath + "/fixture/1_51_0.gif";
                    break;
                  default: //立铣类型
                    gifPath = appData.keyimagepath + "/fixture/1_54_0.gif";
                    break;
                }
              }
              break;
          }
          if (baseKey.locat == 0) {
            //对肩膀
            title.add(S.of(context).key_working_3_11);
            title.add(S.of(context).key_working_3_21);
            title.add(S.of(context).key_working_3_31);
            title.add(S.of(context).key_working_3_41);
            title.add(S.of(context).key_working_3_51);
            switch (baseKey.keyClass) {
              case 1:
                for (var i = 1; i < 6; i++) {
                  image.add("1_51_0_$i.png");
                }
                break;
              case 0:
                for (var i = 1; i < 6; i++) {
                  image.add("1_50_0_$i.png");
                }
                break;
              default:
                for (var i = 1; i < 6; i++) {
                  image.add("1_54_0_$i.png");
                }
                break;
            }
          } else {
            //对头

            title.add(S.of(context).key_working_4_11);
            title.add(S.of(context).key_working_4_21);
            title.add(S.of(context).key_working_4_31);
            title.add(S.of(context).key_working_4_41);
            title.add(S.of(context).key_working_4_51);
            switch (baseKey.keyClass) {
              case 1:
                for (var i = 1; i < 6; i++) {
                  image.add("1_51_1_$i.png");
                }
                break;
              case 0:
                for (var i = 1; i < 6; i++) {
                  image.add("1_50_1_$i.png");
                }
                break;
              default:
                for (var i = 1; i < 6; i++) {
                  image.add("1_54_1_$i.png");
                }
                break;
            }
          }
        } else {
          if (baseKey.locat == 0) {
            //对肩膀
            title.add(S.of(context).key_working_3_11);
            title.add(S.of(context).key_working_3_21);
            title.add(S.of(context).key_working_3_31);
            title.add(S.of(context).key_working_3_41);
            title.add(S.of(context).key_working_3_51);
            switch (baseKey.keyClass) {
              case 1:
                for (var i = 1; i < 6; i++) {
                  image.add("0_51_0_$i.png");
                }
                break;
              case 0:
                for (var i = 1; i < 6; i++) {
                  image.add("0_50_0_$i.png");
                }
                break;
              default:
                for (var i = 1; i < 6; i++) {
                  image.add("0_54_0_$i.png");
                }
                break;
            }
          } else {
            //对头
            title.add(S.of(context).key_working_4_11);
            title.add(S.of(context).key_working_4_21);
            title.add(S.of(context).key_working_4_31);
            title.add(S.of(context).key_working_4_41);
            title.add(S.of(context).key_working_4_51);
            switch (baseKey.keyClass) {
              case 1:
                for (var i = 1; i < 6; i++) {
                  image.add("0_51_1_$i.png");
                }
                break;
              case 0:
                for (var i = 1; i < 6; i++) {
                  image.add("0_50_1_$i.png");
                }
                break;
              default:
                for (var i = 1; i < 6; i++) {
                  image.add("0_54_1_$i.png");
                }
                break;
            }
          }
        }
        break;
      case 6: //FO21 TBE1 旋转夹具

        if (cnCversion.fixtureType == 21) {
          gifPath = appData.keyimagepath + "/fixture/1_fo21.gif";
          title.add(S.of(context).key_working_fo21_11);
          title.add(S.of(context).key_working_fo21_21);
          title.add(S.of(context).key_working_fo21_31);
          title.add(S.of(context).key_working_fo21_41);
          title.add(S.of(context).key_working_fo21_51);
          title.add(S.of(context).key_working_fo21_61);
          title.add(S.of(context).key_working_fo21_71);
          title.add(S.of(context).key_working_fo21_8_21);
          title.add(S.of(context).key_working_fo21_81);
          title.add(S.of(context).key_working_fo21_91);
          title.add(S.of(context).key_working_fo21_101);
          for (var i = 1; i < 12; i++) {
            image.add("1_6_1_$i.png");
          }
        } else {
          gifPath = appData.keyimagepath + "/fixture/0_fo21.gif";
        }
        break;
      case 7: //左边后侧对肩膀
        gifPath = appData.keyimagepath + "/fixture/1_hu66.gif";
        title.add(S.of(context).key_working_hu66_11);
        title.add(S.of(context).key_working_hu66_21);
        title.add(S.of(context).key_working_hu66_31);
        title.add(S.of(context).key_working_hu66_41);
        for (var i = 1; i < 5; i++) {
          image.add("1_7_0_$i.png");
        }
        break;
      case 8: //右边后侧对肩膀
        gifPath = appData.keyimagepath + "/fixture/1_bw9te.gif";
        title.add(S.of(context).key_working_5_11);
        title.add(S.of(context).key_working_5_21);
        title.add(S.of(context).key_working_5_31);
        title.add(S.of(context).key_working_5_41);
        for (var i = 1; i < 5; i++) {
          image.add("1_8_0_$i.png");
        }
        break;
      case 9: //模型加工
        break;
      case 13: //非导电
        break;
    }

    count = min(title.length, image.length);

    for (var i = 0; i < count; i++) {
      temp.add(Text(title[i]));
      temp.add(
        Image.file(
          File(appData.keyimagepath + "/fixture/" + image[i]),
          fit: BoxFit.cover,
        ),
      );
    }
    return temp;
  }

  List<Widget> clampkeytype() {
    // if (copykey) {
    //   return copykeyclampviewlist();
    // }
    return keyclampviewlist();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> awitsetdir() async {
    if (dir) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: const Color(0XFF6E66AA),
        leading: IconButton(
          icon: const Icon(Icons.chevron_left),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: Image.asset(
          "image/tank.png",
          scale: 2.0,
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              children: clampkeytype(),
            ),
          ),
          Row(
            children: [
              SizedBox(
                width: 10.w,
              ),
              Expanded(
                child: ElevatedButton(
                  child: const Text("继续"),
                  onPressed: () {
                    switch (widget.arguments["state"]) {
                      case 0:
                        if (widget.arguments["bitting"] != null) {
                          Navigator.pushReplacementNamed(context, '/keyshow',
                              arguments: {
                                "keydata": widget.arguments["keydata"],
                                "bitting": widget.arguments["bitting"],
                                "dir": dir
                              });
                        } else {
                          Navigator.pushReplacementNamed(context, '/keyshow',
                              arguments: {
                                "keydata": widget.arguments["keydata"],
                                "dir": dir
                              });
                        }
                        break;
                      case 1:
                        sendCmd([cncBtSmd.answer2, 0, 0]);
                        Navigator.pop(context);
                        break;
                      default:
                        Navigator.pop(context);
                        break;
                    }
                  },
                ),
              ),
              SizedBox(
                width: 10.w,
              ),
              Expanded(
                child: ElevatedButton(
                  child: const Text("GIF"),
                  onPressed: () {
                    Navigator.pushNamed(context, '/gifshow',
                        arguments: gifPath);
                  },
                ),
              ),
              SizedBox(
                width: 10.w,
              ),
            ],
          ),
          // SizedBox(
          //   width: double.maxFinite,
          //   child: ElevatedButton(
          //     child: const Text("继续"),
          //     onPressed: () {
          //       switch (widget.arguments["state"]) {
          //         case 0:
          //           if (widget.arguments["bitting"] != null) {
          //             Navigator.pushReplacementNamed(context, '/keyshow',
          //                 arguments: {
          //                   "keydata": widget.arguments["keydata"],
          //                   "bitting": widget.arguments["bitting"],
          //                   "dir": dir
          //                 });
          //           } else {
          //             Navigator.pushReplacementNamed(context, '/keyshow',
          //                 arguments: {
          //                   "keydata": widget.arguments["keydata"],
          //                   "dir": dir
          //                 });
          //           }
          //           break;
          //         case 1:
          //           sendCmd([cncBtSmd.answer2, 0, 0]);
          //           Navigator.pop(context);
          //           break;
          //         default:
          //           Navigator.pop(context);
          //           break;
          //       }
          //     },
          //   ),
          // ),
        ],
      ),
    );
  }
}
