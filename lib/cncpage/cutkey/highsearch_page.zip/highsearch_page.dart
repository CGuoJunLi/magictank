import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class HighSearchPage extends StatefulWidget {
  const HighSearchPage({Key? key}) : super(key: key);
  @override
  State<HighSearchPage> createState() => _HighSearchPageState();
}

class _HighSearchPageState extends State<HighSearchPage> {
  int keyclassindex = 0;
  int keysideindex = 0;
  int keylocationindex = 0;
  bool smartkey = false;
  bool nonconductive = false;
  String inputwide = "";
  String inputtooth = "";
  RegExp pwRegExp = RegExp(r'[0-9]+'); //数字和和字母组成
  List<Map> keyclass = [
    {
      "name": "平铣单边",
      "id": 1,
    },
    {
      "name": "平铣双边",
      "id": 0,
    },
    {
      "name": "立铣外沟单边",
      "id": 3,
    },
    {
      "name": "立铣外沟双边",
      "id": 4,
    },
    {
      "name": "立铣内沟单边",
      "id": 5,
    },
    {
      "name": "立铣内沟双边",
      "id": 2,
    },
  ];
  List<Map> keyside = [
    {
      "name": "上齿",
      "id": 1,
    },
    {
      "name": "下齿",
      "id": 0,
    },
    {
      "name": "上下齿",
      "id": 3,
    },
  ];
  List<Map> keylocation = [
    {
      "name": "肩膀",
      "id": 0,
    },
    {
      "name": "头部",
      "id": 1,
    },
  ];
  List<DropdownMenuItem<int>> selekeyclass() {
    List<DropdownMenuItem<int>> temp = [];
    for (var i = 0; i < keyclass.length; i++) {
      temp.add(DropdownMenuItem(
        value: i,
        child: Text(keyclass[i]["name"]),
      ));
    }
    return temp;
  }

  List<DropdownMenuItem<int>> selekeyside() {
    List<DropdownMenuItem<int>> temp = [];
    for (var i = 0; i < keyside.length; i++) {
      temp.add(DropdownMenuItem(
        value: i,
        child: Text(keyside[i]["name"]),
      ));
    }
    return temp;
  }

  List<DropdownMenuItem<int>> selekeylocation() {
    List<DropdownMenuItem<int>> temp = [];
    for (var i = 0; i < keylocation.length; i++) {
      temp.add(DropdownMenuItem(
        value: i,
        child: Text(keylocation[i]["name"]),
      ));
    }
    return temp;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: const Color(0XFF6E66AA),
        leading: IconButton(
          icon: const Icon(Icons.chevron_left),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: Image.asset(
          "image/tank.png",
          scale: 2.0,
        ),
      ),
      body: Column(children: [
        Expanded(
          child: ListView(
            children: [
              Row(children: [
                SizedBox(
                  width: 120.w,
                  child: const Text(
                    "选择钥匙类型:",
                  ),
                ),
                DropdownButton(
                    value: keyclassindex,
                    items: selekeyclass(),
                    onChanged: (value) {
                      keyclassindex = value as int;
                      switch (keyclass[keyclassindex]["id"]) {
                        case 2: //立铣内沟双边
                        case 4: //立铣外沟双边
                        case 0: //平铣双边
                          keysideindex = 2;
                          break;
                        case 1: //平铣单边
                          keysideindex = 1;
                          break;
                        case 3: //立铣外沟单边
                        case 5: //立铣内沟单边

                          keysideindex = 0;

                          break;
                      }
                      setState(() {});
                    })
              ]),
              Row(children: [
                SizedBox(
                  width: 120.w,
                  child: const Text("选择定位方式:"),
                ),
                DropdownButton(
                    value: keylocationindex,
                    items: selekeylocation(),
                    onChanged: (value) {
                      keylocationindex = value as int;
                      setState(() {});
                    })
              ]),
              Row(children: [
                SizedBox(
                  width: 120.w,
                  child: const Text("选择钥匙有效边:"),
                ),
                DropdownButton(
                    value: keysideindex,
                    items: selekeyside(),
                    onChanged: (value) {
                      switch (keyclass[keyclassindex]["id"]) {
                        case 2: //立铣内沟双边
                        case 4: //立铣外沟双边
                        case 0: //平铣双边
                          keysideindex = 2;
                          break;
                        case 1: //平铣单边
                          keysideindex = 1;
                          break;
                        case 3: //立铣外沟单边
                        case 5: //立铣内沟单边
                          if (value as int == 2) {
                            keysideindex = 1;
                          } else {
                            keysideindex = value;
                          }
                          break;
                        default:
                          keysideindex = value as int;
                          break;
                      }

                      setState(() {});
                    })
              ]),
              CheckboxListTile(
                title: const Text("是否是智能卡"),
                value: smartkey,
                onChanged: (value) {
                  smartkey = !smartkey;
                  if (smartkey) {
                    nonconductive = false;
                  }
                  setState(() {});
                },
              ),
              CheckboxListTile(
                title: const Text("是否是非导电"),
                value: nonconductive,
                onChanged: (value) {
                  nonconductive = !nonconductive;
                  if (nonconductive) {
                    smartkey = false;
                  }
                  setState(() {});
                },
              ),
              Row(
                children: [
                  SizedBox(
                    width: 120.w,
                    child: const Text("输入宽度:"),
                  ),
                  Expanded(
                    child: TextField(
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        LengthLimitingTextInputFormatter(3),
                        //WhitelistingTextInputFormatter(pwRegExp),
                        FilteringTextInputFormatter(pwRegExp, allow: true),
                      ],
                      onChanged: (value) {
                        inputwide = value;
                        // print(inputwide);
                        setState(() {});
                      },
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  SizedBox(
                    width: 120.w,
                    child: const Text("输入齿数:"),
                  ),
                  Expanded(
                    child: TextField(
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        LengthLimitingTextInputFormatter(2),
                        //WhitelistingTextInputFormatter(pwRegExp),
                        FilteringTextInputFormatter(pwRegExp, allow: true),
                      ],
                      onChanged: (value) {
                        inputtooth = value;
                        // print(inputtooth);
                        setState(() {});
                      },
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 10.h,
              ),
              const Text(
                "Tip:提供的参数越多，搜索的结果越准确",
                style: TextStyle(color: Colors.red),
              ),
            ],
          ),
        ),
        Row(
          children: [
            SizedBox(
              width: 10.w,
            ),
            Expanded(
                child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(
                        context,
                      );
                    },
                    child: const Text("取消"))),
            SizedBox(
              width: 10.w,
            ),
            Expanded(
                child: ElevatedButton(
                    onPressed: () {
                      if (inputwide == "") {
                        inputwide = "0";
                      }
                      if (inputtooth == "") {
                        inputtooth = "0";
                      }
                      Navigator.pop(context, {
                        "class": keyclass[keyclassindex]["id"],
                        "side": keyside[keysideindex]["id"],
                        "location": keylocation[keylocationindex]["id"],
                        "wide": int.parse(inputwide),
                        "tooth": int.parse(inputtooth),
                        "smart": smartkey,
                        "non": nonconductive,
                      });
                    },
                    child: const Text("搜索"))),
            SizedBox(
              width: 10.w,
            ),
          ],
        )
      ]),
    );
  }
}
