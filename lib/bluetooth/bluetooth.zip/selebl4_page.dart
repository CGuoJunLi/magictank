import 'dart:convert';

import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter_blue/flutter_blue.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:magictank/alleventbus.dart';
import 'package:magictank/appdata.dart';
import 'package:magictank/userappbar.dart';
import 'package:sn_progress_dialog/progress_dialog.dart';
import 'dart:async';
import 'package:magictank/bluetooth/share_manganger.dart';
//import 'package:bluetooth_enable_fork/bluetooth_enable_fork.dart';
import 'ble4_mananger.dart';
import 'bluetooth_switch.dart';
//import 'enable_bluetooth.dart';

class SeleBL4Page extends StatefulWidget {
  final int machineType;
  const SeleBL4Page(this.machineType, {Key? key}) : super(key: key);
  @override
  _SeleBL4PageState createState() => _SeleBL4PageState();
}

class _SeleBL4PageState extends State<SeleBL4Page> {
  FlutterBlue flutterBlue = FlutterBlue.instance;
  List<Map> allBleNameAry = [];
  bool scanstates = false;
  late ProgressDialog pd;
  Timer? timer;
  //bool btstate = false;
  late StreamSubscription btStateEvent;

  Future<void> enableBT() async {
    BluetoothEnable.enableBluetooth.then((value) {
      debugPrint("value:" + value);
      setState(() async {
        if (value == "true") {
          btmodel.blSwitch = true;
          await Future.delayed(const Duration(seconds: 3));
          beginscanbt();
        }
      });
    });
  }

  Future<void> disenableBT() async {
    BluetoothEnable.disableBluetooth.then((value) {
      debugPrint(value);
    });
  }

  @override
  void dispose() {
    super.dispose();
    btStateEvent.cancel();
  }

  @override
  void initState() {
    //listenbtstate();
    pd = ProgressDialog(context: context);
//  _streamSubscriptionState =
    btStateEvent = eventBus.on<ConnectEvent>().listen(
      (ConnectEvent event) {
        setState(() {
          if (event.state == 1) {
            pd.close();
            debugPrint("返回");
            debugPrint("蓝牙ID");
            debugPrint(btmodel.device.id.toString());
            switch (widget.machineType) {
              case 1:
                appData.upgradeAppData(
                    {"smartbluetoothname": btmodel.device.id.toString()});
                break;
              case 2:
                print(btmodel.device.id);
                appData.upgradeAppData(
                    {"mcbluetoothname": btmodel.device.id.toString()});
                break;
              case 3:
                appData.upgradeAppData(
                    {"bluetoothname": btmodel.device.id.toString()});
                break;
              default:
            }

            btStateEvent.cancel();
            btmodel.state = true;
            Navigator.pop(context);
          }
          if (event.state == 0) {
            disconnect();
            pd.close();
            Fluttertoast.showToast(msg: "设备连接失败,请稍后再试");
          }
        });
      },
    );

    if (btmodel.blSwitch) {
      debugPrint("开始扫描蓝牙");
      beginscanbt();
    }
    //beginscanbt(); //监听蓝牙扫描状态
    //ConnectBL(); //获取连接到的蓝牙列表
    super.initState();
  }

  Future<void> btscanning() async {
    flutterBlue.isScanning.listen((state) {
      scanstates = state;
    });
    debugPrint("蓝牙状态" + scanstates.toString());
    // return states;
  }

  Future<void> beginscanbt() async {
    btscanning();
    if (scanstates == false) {
      flutterBlue.startScan(timeout: const Duration(seconds: 4));
      // // 监听扫描结果
      List temp;
      List<Map> temp2 = [];
      temp = await flutterBlue.connectedDevices;
      for (var i = 0; i < temp.length; i++) {
        temp2.add({
          "name":
              temp[i].name.length > 0 ? temp[i].name : temp[i].id.toString(),
          "drive": temp[i],
          "state": "断开连接"
        });
      }
      setState(() {
        allBleNameAry = List.from(temp2);
      });
    }
  }

  bool selebttype(ScanResult result) {
    switch (widget.machineType) {
      case 1:
        appData.machineType = 1;
        if (result.device.name == "magic-xxx") {
          return true;
        } else {
          return false;
        }
      case 2:
        appData.machineType = 2;
        if (result.device.name == "magic-cloud") {
          return true;
        } else {
          return false;
        }
      case 3:
        appData.machineType = 3;
        String btnamemd5 = "MAGIC STAR" + result.device.id.toString();
        Uint8List content = const Utf8Encoder().convert(btnamemd5);
        Digest digest = md5.convert(content);
        btnamemd5 = base64.encode(digest.bytes);
        if (result.device.name.contains(btnamemd5.substring(0, 7))) {
          return true;
        } else {
          if (appData.root) {
            if (result.device.name == "UN_NAME") {
              return true;
            } else {
              return false;
            }
          }
          return false;
        }

      default:
    }
    return false;
  }

  Widget bltitle(ScanResult result) {
    return selebttype(result)
        //result.device.name.length == 16
        ? Card(
            child: StreamBuilder<BluetoothDeviceState>(
              stream: result.device.state,
              initialData: BluetoothDeviceState.connecting,
              builder: (c, snapshot) {
                VoidCallback? onPressed;
                String text;
                switch (snapshot.data) {
                  case BluetoothDeviceState.connected:
                    onPressed = () {
                      result.device.disconnect();
                      // disconnect();
                    };
                    text = '断开连接';
                    break;
                  case BluetoothDeviceState.disconnected:
                    onPressed = () {
                      pd.show(max: 100, msg: "连接中");
                      connectionBle(result.device);
                      // result.device.
                      // result.device.connect(timeout: Duration(S))
                    };
                    text = '连接';
                    break;
                  default:
                    onPressed = null;
                    text = snapshot.data.toString().substring(21).toUpperCase();
                    break;
                }
                return TextButton(
                  onPressed: onPressed,
                  child: SizedBox(
                    height: 50.h,
                    child: Row(
                      children: [
                        const Icon(Icons.computer),
                        const Expanded(child: SizedBox()),
                        Column(
                          children: [
                            Text(result.device.name.isNotEmpty
                                ? result.device.name
                                : result.device.id.toString()),
                            Text(result.device.id.toString()),
                          ],
                        ),
                        const Expanded(child: SizedBox()),
                        Text(text),
                      ],
                    ),
                  ),
                );
              },
            ),
          )
        : Container();
  }

  List<Widget> bllist(List<ScanResult> snapshot) {
    List<Widget> temp = [];

    //snapshot[i].device.name == "magiclcone" ||
    for (var i = 0; i < snapshot.length; i++) {
      if (snapshot[i].device.name.length > 1) {
        temp.add(Card(
          child: TextButton(
            child: Stack(
              children: [
                Align(
                  child: Text(snapshot[i].device.name),
                  alignment: Alignment.centerLeft,
                ),
                const Align(
                  child: Text("连接设备"),
                  //child: Text("连接"),
                  alignment: Alignment.centerRight,
                ),
              ],
            ),
            onPressed: () {
              setState(() {
                connectionBle(snapshot[i].device);
              });
            },
          ),
        ));
      }
    }

    return temp;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: userAppBar(),
      body: Column(
        children: [
          const Divider(),
          SizedBox(
            height: 20.h,
            child: Stack(
              children: [
                const Align(
                  child: Text("蓝牙开关"),
                  alignment: Alignment.centerLeft,
                ),
                Align(
                  child: Switch(
                    onChanged: (bool value) {
                      setState(() {
                        if (Platform.isAndroid) {
                          btmodel.blSwitch = value;
                          if (value) {
                            enableBT();
                          } else {
                            //  FlutterBlue.instance.stopScan();

                            disconnect();
                            disenableBT();
                          }
                        }
                      });

                      debugPrint("$value");
                    },
                    value: btmodel.blSwitch,
                  ),
                  alignment: Alignment.centerRight,
                ),
              ],
            ),
          ),
          const Divider(),
          SizedBox(
            height: 20.h,
            child: Stack(
              children: [
                const Align(
                  child: Text("自动连接"),
                  alignment: Alignment.centerLeft,
                ),
                Align(
                  child: Switch(
                    onChanged: (bool value) {
                      debugPrint("$value");
                      appData.autoconnect = value;
                      appData.upgradeAppData({"autoconnect": value});
                      setState(() {});
                    },
                    value: appData.autoconnect,
                  ),
                  alignment: Alignment.centerRight,
                ),
              ],
            ),
          ),
          const Divider(),
          Expanded(
            child: btmodel.blSwitch
                ? RefreshIndicator(
                    onRefresh: () {
                      debugPrint("下拉刷新");
                      allBleNameAry.clear();
                      return beginscanbt();
                    },
                    child: StreamBuilder<List<ScanResult>>(
                      stream: FlutterBlue.instance.scanResults,
                      initialData: const [],
                      builder: (c, snapshot) => ListView(
                        children: snapshot.data!
                            .map(
                              (r) => bltitle(
                                r,
                              ),
                            )
                            .toList(),
                      ),
                    ),
                  )
                : const Text("请先打开蓝牙"),
          ),
          const Text(
            "下滑即可刷新列表",
            style: TextStyle(color: Colors.red),
          ),
        ],
      ),
    );
  }
}
