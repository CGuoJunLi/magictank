import 'package:flutter/material.dart';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:magictank/appdata.dart';
import 'package:magictank/dialogshow/dialogpage.dart';
import 'package:magictank/userappbar.dart';

import 'package:sn_progress_dialog/sn_progress_dialog.dart';
import 'dart:async';

import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import '../alleventbus.dart';
import 'ble2_manganger.dart';
import 'package:magictank/bluetooth/share_manganger.dart';

class SeleBL2Page extends StatefulWidget {
  const SeleBL2Page({Key? key}) : super(key: key);
  @override
  _SeleBL2PageState createState() => _SeleBL2PageState();
}

class _SeleBL2PageState extends State<SeleBL2Page> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // 点击返回键即触发该事件
        //  FlutterBlue.instance.stopScan(); //返回停止扫描
        return true; //退出
      },
      child: Scaffold(
        appBar: userAppBar(),
        body: const BlueList(),
      ),
    );
  }
}

class BlueList extends StatefulWidget {
  const BlueList({Key? key}) : super(key: key);

  @override
  _BlueListState createState() => _BlueListState();
}

class _BlueListState extends State<BlueList> {
  //BluetoothState _bluetoothState = BluetoothState.UNKNOWN;
  late ProgressDialog pd;
  final bool start = true;
  StreamSubscription<BluetoothDiscoveryResult>? _streamSubscription;
  List<BluetoothDiscoveryResult> results =
      List<BluetoothDiscoveryResult>.empty(growable: true);
  late StreamSubscription btstatet;
  Timer? time;
  Duration timeout = const Duration(seconds: 20);
  @override
  void initState() {
    //获取蓝牙状态

    FlutterBluetoothSerial.instance.state.then((state) {
      //_bluetoothState = state;
      setState(() {});
    });

    // Listen for futher state changes
    // FlutterBluetoothSerial.instance
    //     .onStateChanged()
    //     .listen((BluetoothState state) {
    // //print("状态改变");
    //   _bluetoothState = state;
    //   setState(() {});
    // });

    _startDiscovery();

    pd = ProgressDialog(context: context);
    //eventBus = EventBus();
    // eventBus.on<BluetoothStateEvent>().listen(
    //   (BluetoothStateEvent event) {
    //     Fluttertoast.showToast(msg: "蓝牙断开");
    //   },
    // );
    btstatet = eventBus.on<ConnectEvent>().listen((event) {
      time!.cancel();
      if (event.state == 1) {
        ////print(pd.isOpen());
        if (pd.isOpen()) {
          pd.close();
        }
        appData.upgradeAppData({"bluetoothname": btmodel.btaddr});
        Navigator.pop(context);
        // Navigator.pushNamed(context, "/");
      } else {
        if (pd.isOpen()) {
          pd.close();
        }
        disconnectBt();
        Fluttertoast.showToast(msg: "连接失败,重启后再试.");
      }
    });
    super.initState();
  }

  _timeOutConnect() {
    time = Timer(timeout, () {
      pd.close();
      showDialog(
          context: context,
          builder: (c) {
            return const MyTextDialog("连接失败");
          });
    });
  }

  Future<void> startscing() async {
    //_restartDiscovery();
  }
  void _startDiscovery() {
    if (btmodel.blSwitch) {
      _streamSubscription =
          FlutterBluetoothSerial.instance.startDiscovery().listen((r) {
        setState(() {
          final existingIndex = results.indexWhere(
              (element) => element.device.address == r.device.address);
          if (existingIndex >= 0) {
            results[existingIndex] = r;
          } else {
            //名字长度==16 才算是 数控机
            if (r.device.name != null) {
              if (r.device.name!.length == 16 || r.device.name == "UN_NAME") {
                results.add(r);
              }
            }
          }
        });
      });

      _streamSubscription!.onDone(() {
        setState(() {});
      });
    }
  }

  // @TODO . One day there should be `_pairDevice` on long tap on something... ;)

  @override
  void dispose() {
    // Avoid memory leak (`setState` after dispose) and cancel discovery
    _streamSubscription?.cancel();

    // btstatet.cancel();
    btstatet.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Expanded(
        child: SwitchListTile(
          title: const Text("蓝牙开关"),
          value: btmodel.blSwitch,
          onChanged: (bool value) {
            // Do the request and update with the true value then
            future() async {
              // async lambda seems to not working
              ////print(value);
              if (value) {
                await FlutterBluetoothSerial.instance.requestEnable();
              } else {
                await FlutterBluetoothSerial.instance.requestDisable();
              }
            }

            future().then((_) {
              _startDiscovery();
              setState(() {});
            });
          },
        ),
        flex: 1,
      ),
      Expanded(
        child: SwitchListTile(
          title: const Text("自动连接"),
          value: appData.autoconnect,
          onChanged: (value) {
            appData.autoconnect = value;
            appData.upgradeAppData({"autoconnect": appData.autoconnect});
            setState(() {});
          },
        ),
        flex: 1,
      ),
      Expanded(
        flex: 9,
        child: RefreshIndicator(
          onRefresh: () {
            debugPrint("下拉刷新");
            _startDiscovery();
            return startscing();
            //   return _startDiscovery();
          },
          child: ListView.builder(
            itemCount: results.length,
            itemBuilder: (BuildContext context, index) {
              BluetoothDiscoveryResult result = results[index];
              final device = result.device;
              //final address = device.address;
              return BluetoothDeviceListEntry(
                device: device,
                rssi: result.rssi,
                onTap: () async {
                  debugPrint("点击了项目");
                  // FlutterBluetoothSerial.instance
                  //     .setPairingRequestHandler((request) {
                  //   return Future.value("1234");
                  // });
                  try {
                    FlutterBluetoothSerial.instance.setPairingRequestHandler(
                        (BluetoothPairingRequest request) {
                      ////print("Trying to auto-pair with Pin 1234");
                      if (request.pairingVariant == PairingVariant.Pin) {
                        return Future.value("1234");
                      }
                      return Future.value(null);
                    });
                  } catch (e) {
                    debugPrint("$e");
                  }
                  pd.show(max: 100, msg: "连接中");
                  _timeOutConnect();
                  connectBt(device);
                },
              );
            },
          ),
        ),
      ),
    ]);
  }
}

class BluetoothDeviceListEntry extends ListTile {
  BluetoothDeviceListEntry({
    Key? key,
    required BluetoothDevice device,
    int? rssi,
    GestureTapCallback? onTap,
    bool enabled = true,
  }) : super(
          key: key,
          onTap: onTap,
          enabled: enabled,
          leading: const Icon(
              Icons.devices), // @TODO . !BluetoothClass! class aware icon
          title: Text(device.name ?? ""),
          subtitle: Text(device.address.toString()),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              device.isConnected
                  ? const Icon(Icons.import_export)
                  : const SizedBox(),
              device.isBonded ? const Icon(Icons.link) : const SizedBox(),
            ],
          ),
        );
}
